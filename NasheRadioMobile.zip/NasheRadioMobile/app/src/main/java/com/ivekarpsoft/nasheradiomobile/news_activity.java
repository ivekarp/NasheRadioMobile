package com.ivekarpsoft.nasheradiomobile;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class news_activity extends AppCompatActivity {

    public ArrayList<String> news_list = new ArrayList<String>();
    private ArrayAdapter<String> adapter;
    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_activity);

        lv = (ListView)findViewById(R.id.news_listview);

        ShowNews showNews = new ShowNews();
        showNews.execute();

        adapter = new ArrayAdapter<String>(
                this,
                R.layout.list_item,
                news_list
        );
    }

    public class ShowNews extends AsyncTask<String, Void, Void> {

        String news_url = "https://www.nashe.ru/news/";
        Document doc;

        @Override
        protected Void doInBackground(String... strings) {
            try {
                doc = Jsoup.connect(news_url).get();
                Elements newsHeadlines = doc.select("span.news__name");
                Elements newsUrls = doc.select("a.news__item");
                news_list.clear();
                for (Element headline : newsHeadlines)
                {
                    news_list.add(headline.text());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            lv.setAdapter(adapter);
        }
    }
}