package com.ivekarpsoft.nasheradiomobile;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import com.ivekarpsoft.nasheradiomobile.player.PlaybackStatus;
import com.ivekarpsoft.nasheradiomobile.player.RadioManager;
import com.ivekarpsoft.nasheradiomobile.util.Shoutcast;
import com.ivekarpsoft.nasheradiomobile.util.ShoutcastHelper;
import com.ivekarpsoft.nasheradiomobile.util.ShoutcastListAdapter;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.jsoup.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnItemClick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.playTrigger)
    ImageButton trigger;

    @BindView(R.id.listview)
    ListView listView;

    @BindView(R.id.name)
    TextView textView;

    @BindView(R.id.sub_player)
    View subPlayer;

    RadioManager radioManager;

    String streamURL;

    Button btn_singer;
    Button btn_show_news;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        btn_singer = (Button)findViewById(R.id.btn_singer);
        btn_show_news = (Button)findViewById(R.id.btn_show_news);

        ButterKnife.bind(this);

        setSupportActionBar(toolbar);

        radioManager = RadioManager.with(this);

        listView.setAdapter(new ShoutcastListAdapter(this, ShoutcastHelper.retrieveShoutcasts(this)));


        btn_singer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Singer singer = new Singer();
                singer.execute();

            }
        });

        btn_show_news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, news_activity.class);
                startActivity(intent);
//                ShowNews showNews = new ShowNews();
//                showNews.execute();
            }
        });
    }

    public class Singer_json {
//        Класс для парсинга json'а
        private String id;
        private String uniqueid;
        private String last_modified;
        private String artist;
        private String title;

        public Singer_json(String id, String uniqueid, String last_modified, String artist, String title) {
            this.id = id;
            this.uniqueid = uniqueid;
            this.last_modified = last_modified;
            this.artist = artist;
            this.title = title;
        }
    }

    private class Singer extends AsyncTask<Void, Void, String>
    {
        String singer_url = "http://metanashe.hostingradio.ru/current.json";
        Gson gson = new Gson();
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(MainActivity.this);
            pd.setMessage("Подождите");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try {
                URL url = new URL(singer_url);
                connection = (HttpURLConnection)url.openConnection();
                connection.connect();

                InputStream i_stream = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(i_stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";
                while ((line = reader.readLine()) != null)
                {
                    buffer.append(line + "\n");
                }
                return buffer.toString();
            }

            catch (MalformedURLException e) {
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (pd.isShowing())
                pd.dismiss();
            Singer_json singer_json = gson.fromJson(result, Singer_json.class);
            Toast.makeText(getApplicationContext(), "В эфире: " + singer_json.artist + " - " + singer_json.title, Toast.LENGTH_SHORT).show();
//            Log.d("json",singer_json.artist + " - " + singer_json.title);
        }
    }


    @Override
    public void onStart() {

        super.onStart();

        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {

        EventBus.getDefault().unregister(this);

        super.onStop();
    }

    @Override
    protected void onDestroy() {

        radioManager.unbind();

        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();

        radioManager.bind();
    }

    @Override
    public void onBackPressed() {

        finish();
    }

    @Subscribe
    public void onEvent(String status){

        switch (status){

            case PlaybackStatus.LOADING:

                // loading

                break;

            case PlaybackStatus.ERROR:

                Toast.makeText(this, R.string.no_stream, Toast.LENGTH_SHORT).show();

                break;

        }

        trigger.setImageResource(status.equals(PlaybackStatus.PLAYING)
                ? R.drawable.ic_pause_black
                : R.drawable.ic_play_arrow_black);

    }

    @OnClick(R.id.playTrigger)
    public void onClicked(){

        if(TextUtils.isEmpty(streamURL)) return;

        radioManager.playOrPause(streamURL);
    }


    @OnItemClick(R.id.listview)
    public void onItemClick(AdapterView<?> parent, View view, int position, long id){

        Shoutcast shoutcast = (Shoutcast) parent.getItemAtPosition(position);
        if(shoutcast == null){

            return;

        }

        textView.setText(shoutcast.getName());

        subPlayer.setVisibility(View.VISIBLE);

        streamURL = shoutcast.getUrl();

        radioManager.playOrPause(streamURL);
    }
}
